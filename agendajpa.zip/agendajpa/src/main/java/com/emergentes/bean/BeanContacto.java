package com.emergentes.bean;

import com.emergentes.entidades.Estudiante;
import com.emergentes.jpa.EstudianteJpaController;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class BeanContacto {
    private EntityManagerFactory emf;
    private EstudianteJpaController jpaEstudiante;

    public BeanContacto() {
        emf = Persistence.createEntityManagerFactory("UPagenda");
        jpaEstudiante= new EstudianteJpaController(emf);
        
    }
    public List<Estudiante> listarTodos()
    {
        
        return jpaEstudiante.findEstudianteEntities();
        
    }
}
